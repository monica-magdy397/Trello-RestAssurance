package PostRequests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;

public class createList {
    public static void main(String[] args) {

        RestAssured.baseURI= "https://api.trello.com";
        RequestSpecification request = RestAssured.given();
        request.basePath("/1/lists");
        request.queryParam("key","f52a37c98f963d04bf22e14ad204872a");
        request.queryParam("token","ATTA62d1ae6ded70e59ec81c7c860207b7f1020fff6b8666e37b40dd81baa5a334116E5AD3AD");

        request.queryParam("name","Listname");
        request.queryParam("idBoard","63bdfae51a020e00fd18c22f");

        request.header("Content-Type","application/json");
        request.body("{    \"name\": \"Name for the list\",    \"pos\": \"top\"}");

        Response response = request.post();
        response.prettyPrint();

        JsonPath path =response.jsonPath();
        String listID = path.getString("id");
        System.out.println(listID);

        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode,200);;


    }
}
