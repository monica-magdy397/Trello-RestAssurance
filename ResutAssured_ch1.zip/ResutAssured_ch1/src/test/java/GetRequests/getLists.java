package GetRequests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;

public class getLists {
    public static void main(String[] args) {

        RestAssured.baseURI= "https://api.trello.com";
        RequestSpecification request = RestAssured.given();
        request.basePath("/1/boards/63bdfae51a020e00fd18c22f/lists");

        request.queryParam("key","f52a37c98f963d04bf22e14ad204872a");
        request.queryParam("token","ATTA62d1ae6ded70e59ec81c7c860207b7f1020fff6b8666e37b40dd81baa5a334116E5AD3AD");
        request.queryParam("cards","all");
        request.queryParam("card_fields","all");
        request.queryParam("filter","all");
        request.queryParam("fields","all");


        Response response = request.get();
        response.prettyPrint();

        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode,200);
    }
}