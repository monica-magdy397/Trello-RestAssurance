package DeleteRequests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;

public class deleteBoard {
    public static void main(String[] args) {

        RestAssured.baseURI= "https://api.trello.com";
        RequestSpecification request = RestAssured.given();
        request.basePath("/1/boards/5e0864871982b18bef43dd7c");

        request.queryParam("key","f52a37c98f963d04bf22e14ad204872a");
        request.queryParam("token","ATTA62d1ae6ded70e59ec81c7c860207b7f1020fff6b8666e37b40dd81baa5a334116E5AD3AD");

        Response response = request.delete();
        response.prettyPrint();

        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode,200);
    }
}

