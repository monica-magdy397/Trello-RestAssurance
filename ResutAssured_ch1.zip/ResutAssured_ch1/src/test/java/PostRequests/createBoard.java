package PostRequests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;

public class createBoard {
    public static void main(String[] args) {

        RestAssured.baseURI= "https://api.trello.com";
        RequestSpecification request = RestAssured.given();
        request.basePath("/1/boards");
        request.queryParam("key","f52a37c98f963d04bf22e14ad204872a");
        request.queryParam("token","ATTA62d1ae6ded70e59ec81c7c860207b7f1020fff6b8666e37b40dd81baa5a334116E5AD3AD");

        request.queryParam("name","name");
        request.queryParam("id","63bdef947022810037ec3eb7");

        request.header("Content-Type","application/json");
        request.body("{ \"defaultLabels\": \"true\"," +
                "    \"defaultLists\": \"true\",    " +
                "\"desc\": \"A new description for the board\"," +
                "    \"keepFromSource\": \"cards\"," +
                "    \"powerUps\": \"calendar\"," +
                "    \"prefs_permissionLevel\": \"public\"," +
                "\"prefs_voting\": \"disabled\",    " +
                "\"prefs_comments\": \"disabled\",    " +
                "\"prefs_invitations\": \"members\",    " +
                "\"prefs_selfJoin\": \"true\",    " +
                "\"prefs_cardCovers\": \"true\",    " +
                "\"prefs_background\": \"blue\",    " +
                "\"prefs_cardAging\": \"regular\"}");
        Response response = request.post();
        response.prettyPrint();

        JsonPath path =response.jsonPath();
        String bordID = path.getString("id");
        System.out.println(bordID);

        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode,200);;
    }
}

